import fetch from "../include/fetch.js";
export function fetchCurrentTemperature(coords) {
    // TODO
    /*
        @param a longitude and latitude
        @return a Promise that fulfils with a TemperatureReading object
                The "time" field should be an array of times.
                The "temperature_2m" field should be an array of corresponding temperature measurements.
    **/
    const query = `https://220.maxkuechen.com/currentTemperature/forecast?latitude=${coords.lat}&longitude=${coords.lon}&hourly=temperature_2m&temperature_unit=fahrenheit`;
    return fetch(query)
        .then((result) => result.ok ? result.json() : {})
        .then((jsonobj) => "hourly" in jsonobj ? jsonobj["hourly"] : {})
        .then((hourlyobj) => {
        const obj = { time: [], temperature_2m: [] };
        if ("time" in hourlyobj && Array.isArray(hourlyobj["time"]))
            hourlyobj["time"].forEach(elem => obj.time.push("".concat(elem)));
        if ("temperature_2m" in hourlyobj && Array.isArray(hourlyobj["temperature_2m"]))
            hourlyobj["temperature_2m"].forEach(elem => obj.temperature_2m.push(Number.parseFloat(elem)));
        return obj;
    });
}
//# sourceMappingURL=fetchCurrentTemperature.js.map