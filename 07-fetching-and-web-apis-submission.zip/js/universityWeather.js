import { fetchUniversities } from "./fetchUniversities.js";
import { fetchGeoCoord } from "./fetchGeoCoord.js";
import { fetchCurrentTemperature } from "./fetchCurrentTemperature.js";
export function fetchUniversityWeather(universityQuery, transformName) {
    // TODO
    const resObj = { totalAverage: 0 };
    let total = 0;
    return fetchUniversities(universityQuery).then((uNames) => uNames.map((uName) => fetchGeoCoord(transformName !== undefined ? transformName(uName) : uName).then((geoco) => fetchCurrentTemperature(geoco).then((temper) => {
        resObj[uName] = (temper.temperature_2m.length === 0 ?
            0 :
            temper.temperature_2m.reduce((s, a) => s + a, 0) / temper.temperature_2m.length);
        total += resObj[uName];
    })))).then((proms) => proms.length === 0 ?
        Promise.reject(new Error("No results found for query.")) :
        Promise.all(proms).then((_) => {
            resObj.totalAverage = total / _.length;
            return resObj;
        }));
}
export function fetchUMassWeather() {
    // TODO
    return fetchUniversityWeather("University of Massachusetts", (x) => {
        if (x === "University of Massachusetts at Amherst")
            return "University of Massachusetts Amherst";
        if (x === "University of Massachusetts at Lowell")
            return "University of Massachusetts Lowell";
        if (x === "University of Massachusetts at Dartmouth")
            return "University of Massachusetts Dartmouth";
        return x;
    });
}
export function fetchUCalWeather() {
    // TODO
    return fetchUniversityWeather("University of California");
}
//# sourceMappingURL=universityWeather.js.map