// "use strict";
import fetch from "../include/fetch.js";
import {fetchGeoCoord, GeoCoord} from "./fetchGeoCoord";

// TODO - Now its your turn to make the working example! :)